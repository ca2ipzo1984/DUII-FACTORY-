/**
 * ==============================================================================
 * SCRIPT NAME : 13_GroupLiveMap.gs
 * VERSION     : v1.0.0-PROD-ISO9009
 * STANDARD    : DUII_FACTORY_CORE_SPINE_ISO9009
 * DESCRIPTION : Real-Time Group GPS Tracking & Shared Target Waypoint Engine
 * ==============================================================================
 */

var GroupLiveMap = (function () {
  var CACHE_EXPIRY_SEC = 21600; // 6 ชั่วโมง
  var ACTIVE_WINDOW_MIN = 30;   // สมาชิกไม่ส่งพิกัดเกิน 30 นาทีถือว่าออฟไลน์

  function getSs_() {
    var ssId = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
    if (!ssId) throw new Error('MISSING_SPREADSHEET_ID');
    return SpreadsheetApp.openById(ssId);
  }

  function getLocationsSheet_() {
    var ss = getSs_();
    var sheet = ss.getSheetByName('LIVE_LOCATIONS');
    if (!sheet) {
      sheet = ss.insertSheet('LIVE_LOCATIONS');
      sheet.appendRow(['UserID', 'Name', 'AvatarUrl', 'Latitude', 'Longitude', 'Speed_Kmh', 'Accuracy_M', 'LastUpdate', 'Status']);
      sheet.setFrozenRows(1);
    }
    return sheet;
  }

  function getTargetSheet_() {
    var ss = getSs_();
    var sheet = ss.getSheetByName('TARGET_WAYPOINT');
    if (!sheet) {
      sheet = ss.insertSheet('TARGET_WAYPOINT');
      sheet.appendRow(['TargetName', 'Latitude', 'Longitude', 'SetBy', 'UpdatedAt', 'Note']);
      sheet.setFrozenRows(1);
      sheet.appendRow(['จุดนัดพบตั้งต้น', 13.7563, 100.5018, 'Admin', Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm:ss'), '']);
    }
    return sheet;
  }

  /**
   * 1. อัปเดตพิกัดสดของสมาชิกแต่ละคน (Atomic Cache + Fallback Sheet)
   */
  function updateMemberLocation(data) {
    var userId = String(data.userId || 'GUEST_' + Math.floor(Math.random() * 1000));
    var name = String(data.name || 'ไม่ระบุชื่อ').substring(0, 30);
    var avatar = String(data.avatar || 'https://cdn-icons-png.flaticon.com/512/149/149071.png');
    var lat = parseFloat(data.lat);
    var lng = parseFloat(data.lng);
    var speed = parseFloat(data.speed || 0);
    var accuracy = parseFloat(data.accuracy || 0);
    var nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm:ss');

    if (isNaN(lat) || isNaN(lng)) return { status: 'error', message: 'พิกัดละติจูด/ลองจิจูดไม่ถูกต้อง' };

    // เก็บลง CacheService ทันทีเพื่อความเร็วระดับมิลลิวินาที
    var cache = CacheService.getScriptCache();
    var memberObj = {
      userId: userId,
      name: name,
      avatar: avatar,
      lat: lat,
      lng: lng,
      speed: speed,
      accuracy: accuracy,
      lastUpdate: nowStr,
      timestamp: Date.now()
    };
    cache.put('loc_' + userId, JSON.stringify(memberObj), CACHE_EXPIRY_SEC);

    // เก็บรายชื่อสมาชิกที่ใช้งานอยู่ในคีย์รวม
    var membersListRaw = cache.get('members_index') || '[]';
    var membersList = [];
    try { membersList = JSON.parse(membersListRaw); } catch (e) { membersList = []; }
    if (membersList.indexOf(userId) === -1) {
      membersList.push(userId);
      cache.put('members_index', JSON.stringify(membersList), CACHE_EXPIRY_SEC);
    }

    // ซิงก์ลง Google Sheet แบบไม่บล็อกเวลา
    try {
      var lock = LockService.getScriptLock();
      if (lock.tryLock(3000)) {
        var sh = getLocationsSheet_();
        var dataRows = sh.getDataRange().getValues();
        var rowIndex = -1;
        for (var i = 1; i < dataRows.length; i++) {
          if (String(dataRows[i][0]) === userId) { rowIndex = i + 1; break; }
        }
        var rowData = [userId, name, avatar, lat, lng, speed, accuracy, nowStr, 'ONLINE'];
        if (rowIndex > 0) {
          sh.getRange(rowIndex, 1, 1, 9).setValues([rowData]);
        } else {
          sh.appendRow(rowData);
        }
        lock.releaseLock();
      }
    } catch (errSheet) {
      console.warn('[Sync Sheet Warn] ' + errSheet.message);
    }

    return { status: 'success', message: 'บันทึกพิกัดสำเร็จ', member: memberObj };
  }

  /**
   * 2. ดึงข้อมูลพิกัดทั้งแก๊ง + จุดเป้าหมายล่าสุด
   */
  function getGroupLiveState() {
    var cache = CacheService.getScriptCache();
    var membersListRaw = cache.get('members_index') || '[]';
    var membersList = [];
    try { membersList = JSON.parse(membersListRaw); } catch (e) { membersList = []; }

    var activeMembers = [];
    var nowMs = Date.now();

    for (var i = 0; i < membersList.length; i++) {
      var uId = membersList[i];
      var raw = cache.get('loc_' + uId);
      if (raw) {
        try {
          var m = JSON.parse(raw);
          // กรองสมาชิกที่อัปเดตพิกัดภายใน ACTIVE_WINDOW_MIN
          if (nowMs - m.timestamp < (ACTIVE_WINDOW_MIN * 60 * 1000)) {
            activeMembers.push(m);
          }
        } catch (e) {}
      }
    }

    // ถ้าแคชว่างเปล่า ให้ดึงจากชีตสำรอง
    if (activeMembers.length === 0) {
      try {
        var sh = getLocationsSheet_();
        var dataRows = sh.getDataRange().getValues();
        for (var r = 1; r < dataRows.length; r++) {
          activeMembers.push({
            userId: String(dataRows[r][0]),
            name: String(dataRows[r][1]),
            avatar: String(dataRows[r][2]),
            lat: parseFloat(dataRows[r][3]),
            lng: parseFloat(dataRows[r][4]),
            speed: parseFloat(dataRows[r][5]),
            accuracy: parseFloat(dataRows[r][6]),
            lastUpdate: String(dataRows[r][7]),
            timestamp: nowMs
          });
        }
      } catch (e) {}
    }

    // ดึงจุดเป้าหมาย (Target Waypoint)
    var targetObj = null;
    var cachedTarget = cache.get('shared_target_waypoint');
    if (cachedTarget) {
      try { targetObj = JSON.parse(cachedTarget); } catch (e) {}
    }
    if (!targetObj) {
      try {
        var tSh = getTargetSheet_();
        if (tSh.getLastRow() >= 2) {
          var tRow = tSh.getRange(2, 1, 1, 6).getValues()[0];
          targetObj = {
            targetName: String(tRow[0]),
            lat: parseFloat(tRow[1]),
            lng: parseFloat(tRow[2]),
            setBy: String(tRow[3]),
            updatedAt: String(tRow[4]),
            note: String(tRow[5] || '')
          };
          cache.put('shared_target_waypoint', JSON.stringify(targetObj), CACHE_EXPIRY_SEC);
        }
      } catch (e) {}
    }

    return {
      status: 'success',
      count: activeMembers.length,
      members: activeMembers,
      target: targetObj,
      serverTime: Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm:ss')
    };
  }

  /**
   * 3. ตั้งจุดเป้าหมายปลายทางรวม (Shared Target Waypoint)
   */
  function setTargetWaypoint(targetData) {
    var name = String(targetData.targetName || 'จุดหมายรวม').substring(0, 50);
    var lat = parseFloat(targetData.lat);
    var lng = parseFloat(targetData.lng);
    var setBy = String(targetData.setBy || 'Admin').substring(0, 30);
    var note = String(targetData.note || '').substring(0, 100);
    var nowStr = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy-MM-dd HH:mm:ss');

    if (isNaN(lat) || isNaN(lng)) return { status: 'error', message: 'พิกัดเป้าหมายไม่ถูกต้อง' };

    var targetObj = {
      targetName: name,
      lat: lat,
      lng: lng,
      setBy: setBy,
      updatedAt: nowStr,
      note: note
    };

    // บันทึกลง CacheService ทันที
    CacheService.getScriptCache().put('shared_target_waypoint', JSON.stringify(targetObj), CACHE_EXPIRY_SEC);

    // บันทึกลง Sheet แถวที่ 2
    try {
      var lock = LockService.getScriptLock();
      if (lock.tryLock(5000)) {
        var sh = getTargetSheet_();
        sh.getRange(2, 1, 1, 6).setValues([[name, lat, lng, setBy, nowStr, note]]);
        lock.releaseLock();
      }
    } catch (err) {
      console.warn('[Target Sheet Save Warn] ' + err.message);
    }

    return { status: 'success', message: 'ปักหมุดเป้าหมายใหม่สำเร็จ', target: targetObj };
  }

  return {
    updateLocation: updateMemberLocation,
    getState: getGroupLiveState,
    setTarget: setTargetWaypoint
  };
})();

// ==============================================================================
// WEB APP API ROUTING & ENTRY POINT
// ==============================================================================
function handleGroupLiveMapRequest(e) {
  var params = e.parameter || {};
  var action = (params.action || '').toUpperCase();

  // จัดการ CORS
  var output = ContentService.createTextOutput();
  output.setMimeType(ContentService.MimeType.JSON);

  try {
    if (action === 'GET_LIVE_STATE' || action === 'GET_STATE') {
      var state = GroupLiveMap.getState();
      return output.setContent(JSON.stringify(state));
    }

    if (action === 'UPDATE_LOCATION') {
      var updateRes = GroupLiveMap.updateLocation(params);
      return output.setContent(JSON.stringify(updateRes));
    }

    if (action === 'SET_TARGET') {
      var targetRes = GroupLiveMap.setTarget(params);
      return output.setContent(JSON.stringify(targetRes));
    }

    return output.setContent(JSON.stringify({ status: 'unknown_action', message: 'ไม่พบคำสั่ง action ที่ระบุ' }));
  } catch (err) {
    return output.setContent(JSON.stringify({ status: 'error', message: err.message }));
  }
}
