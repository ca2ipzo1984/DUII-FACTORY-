# คำสั่งผลิตและติดตั้งโมดูล 13: GROUP LIVE MAP & SHARED WAYPOINT (ISO 9009)

**เรียน: ทีมช่างเทคนิค / วิศวกรโรงงาน DUII FACTORY**  
**รหัสโมดูล**: `13_GroupLiveMap`  
**มาตรฐาน**: `DUII_FACTORY_CORE_SPINE_ISO9009`  
**สถานะ**: พร้อมติดตั้งใช้งานจริง (Production-Ready)

---

## 1. ภาพรวมสถาปัตยกรรม (Architecture Blueprint)

ระบบแชร์พิกัดสดกลุ่ม 10 คน และปักหมุดเป้าหมายรวม (Group Live Tracking & Shared Target Waypoint):
1. **Frontend**: ใช้ **Leaflet.js + OpenStreetMap (ฟรี 100% ต้นทุน 0 บาท)** ไม่ต้องง้อ Google Maps API
2. **GPS Polling**: ดึงพิกัดจากมือถือสมาชิกผ่าน HTML5 Geolocation (`watchPosition`)
3. **Backend Sync**: ส่งเข้า Apps Script Web App แคชผ่าน `CacheService` เพื่อความเร็วระดับมิลลิวินาที และสำรองลง Google Sheets แท็บ `LIVE_LOCATIONS` และ `TARGET_WAYPOINT`
4. **Shared Target**: ใครในกลุ่มจิ้มปักหมุดธงแดง (🚩) พิกัดเป้าหมายจะเด้งซิงก์ให้ทุกคนเห็นพร้อมกันทันที พร้อมคำนวณระยะทางแบบ Real-time (Haversine Formula)

---

## 2. ไฟล์ในชุดแพ็กเกจ

| ไฟล์ | หน้าที่ | วิธีใช้งาน |
|---|---|---|
| **`13_GroupLiveMap.gs`** | Backend Apps Script API (รับ-ส่งพิกัด, แคช, คำนวณสถานะ) | วางเป็นไฟล์ใหม่ในโปรเจกต์ Google Apps Script |
| **`13_GroupLiveMap.html`** | หน้าแผนที่แสดงผลสำหรับสมาชิกทุกคนบนมือถือ | นำขึ้น GitHub Pages หรือโฮสต์บน Web App / LINE LIFF |

---

## 3. ขั้นตอนการติดตั้งของทีมช่าง (Step-by-Step Deployment)

### ขั้นตอนที่ 1: ติดตั้งฝั่ง Backend (`13_GroupLiveMap.gs`)
1. เปิดโปรเจกต์ Google Apps Script หลักของโรงงาน
2. กด `+` เพิ่มไฟล์สคริปต์ ตั้งชื่อว่า **`13_GroupLiveMap.gs`**
3. คัดลอกโค้ดจากไฟล์ `13_GroupLiveMap.gs` ไปวาง
4. ในฟังก์ชัน `doGet(e)` ของสคริปต์หลัก เพิ่มบรรทัดนี้เพื่อต่อสายท่อ API:
   ```javascript
   if (e.parameter && e.parameter.action) {
     return handleGroupLiveMapRequest(e);
   }
   ```

### ขั้นตอนที่ 2: ติดตั้งฝั่ง Frontend (`13_GroupLiveMap.html`)
1. นำไฟล์ `13_GroupLiveMap.html` ไปวางใน GitHub Pages Repository (`ca2ipzo1984/DUII-FACTORY-`) หรือโฟลเดอร์ Web App
2. เปิดไฟล์แล้วนำ URL ของ Web App (`.../exec`) ไปใส่ตรงตัวแปร:
   ```javascript
   const BACKEND_ENDPOINT = "ใส่ Web App URL ของคุณที่นี่";
   ```
3. ส่งลิงก์หน้าเว็บนี้ให้สมาชิกทั้ง 10 คนเปิดผ่านมือถือได้ทันที

### ขั้นตอนที่ 3: ลงทะเบียนเข้าคลังโมดูล `modules.js` (FACTORY_REGISTRY)
เพิ่ม Schema โมดูลลงใน `modules.js` เพื่อให้ระบบประกอบบอทใน PWA มองเห็น:
```javascript
{
  id: "13_GroupLiveMap",
  type: "module",
  name: "13_GroupLiveMap (Squad Live GPS & Waypoint)",
  category: "Location & IoT",
  commands: ["/map", "/พิกัดแก๊ง", "/เป้าหมาย"],
  description: "ระบบแผนที่ติดตามพิกัดสดกลุ่ม 10 คน พร้อมปักหมุดเป้าหมายรวมและคำนวณระยะทางแบบเรียลไทม์ (ต้นทุน 0 บาท)",
  properties: [],
  setupGuide: "### 🗺️ 13_GroupLiveMap.gs\nวางใน Apps Script และเปิดหน้า 13_GroupLiveMap.html เพื่อดูพิกัดทั้ง 10 คน",
  functionDeclaration: {
    name: "get_squad_locations",
    description: "ดึงพิกัดสดของสมาชิกในกลุ่มและจุดหมายปลายทางรวม",
    parameters: { type: "OBJECT", properties: {} }
  },
  codeSnippet: `// FILE: Modules/13_GroupLiveMap.gs\n// รันผ่าน GroupLiveMap.getState()`
}
```

### ขั้นตอนที่ 4: เชื่อมคำสั่งแชท LINE (`/map`)
ใน `00_CoreSpine.gs` ตรงฟังก์ชัน `handleCommands_` เพิ่มดักคำสั่ง:
```javascript
if (lower === '/map' || t === '/พิกัดแก๊ง') {
  var mapUrl = "https://ca2ipzo1984.github.io/DUII-FACTORY-/13_GroupLiveMap.html";
  replyText_(token, "🗺️ แผนที่พิกัดแก๊งสด & จุดนัดพบรวม:\n" + mapUrl);
  return true;
}
```

---
**ตรวจรับและอนุมัติโดย**: ไอ้ดุ่ย (Duii) หัวหน้าช่างใหญ่ DUII FACTORY ISO 9009
